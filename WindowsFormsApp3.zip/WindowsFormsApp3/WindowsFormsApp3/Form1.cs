﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        const int paddlespeed = 3, top = 0, bottom = 350;
        bool uppressedp1, downpressedp1, uppressedp2, downpressedp2;
        public Form1()
            Ball ball;

        public Form1()
        {
            InitializeComponent();
            ball = new Ball(ball);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //player 1
            if (uppressedp1)
            {
                paddle1.Location = new Point(paddle1.Location.X,
                    Math.Max (top, 
                    Math.Min(bottom, 
                    paddle1.Location.Y - paddlespeed
                    )));
            }
            if (downpressedp1)
            {
                paddle1.Location = new Point(paddle1.Location.X, 
                    Math.Max(top, 
                    Math.Min(bottom, 
                    paddle1.Location.Y + paddlespeed
                    )));
            }

            //player 2
            if (uppressedp2)
            {
                paddle2.Location = new Point(paddle2.Location.X, 
                    Math.Max(top, 
                    Math.Min(bottom, 
                    paddle2.Location.Y - paddlespeed
                    )));
            }
            if (downpressedp2)
            {
                paddle2.Location = new Point(paddle2.Location.X, 
                    Math.Max(top, 
                    Math.Min(bottom, 
                    paddle2.Location.Y + paddlespeed
                    )));
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            //player 1
            switch (e.KeyCode)
            {
                case Keys.W:
                    uppressedp1 = true;
                    break;
                case Keys.S:
                    downpressedp1 = true;
                    break;
            }

            //player 2
            switch (e.KeyCode)
            {
                case Keys.Up:
                    uppressedp2 = true;
                    break;
                case Keys.Down:
                    downpressedp2 = true;
                    break;
            }
        }
        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            //player 1
            switch (e.KeyCode)
            {
                case Keys.W:
                    uppressedp1 = false;
                    break;
                case Keys.S:
                    downpressedp1 = false;
                    break;
            }

            //player 2
            switch (e.KeyCode)
            {
                case Keys.Up:
                    uppressedp2 = false;
                    break;
                case Keys.Down:
                    downpressedp2 = false;
                    break;
            }
        }

    }
}
